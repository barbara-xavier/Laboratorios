# NIvelamento01_02-02
Atividade de Nivelamento N1
# Elabore um algoritmo que calcule a idade média de 5 alunos.
